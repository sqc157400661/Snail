package cn.itcast.dtx.txmsgdemo.bank2;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TxMsgBank2Service {

	public static void main(String[] args) {
		SpringApplication.run(TxMsgBank2Service.class, args);
	}

}
